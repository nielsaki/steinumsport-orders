<?php
/**
 * Pure-PHP sanitization + validation (no WP dependency).
 *
 * @package Steinum_Sport_Clothes
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'SSC_TESTING' ) ) {
	exit;
}

/**
 * Form input sanitizer + validator.
 */
class SSC_Sanitizer {

	/** @return array<string, string> */
	public static function labels(): array {
		return array(
			'club_name'     => 'Navn á felagi',
			'boat_name'     => 'Navn á báti',
			'count_women'   => 'Nøgd kvinnur',
			'count_men'     => 'Nøgd menn',
			'sizes_women'   => 'Stødd kvinnur / eventuell persónsnøvn',
			'sizes_men'     => 'Stødd menn / eventuell persónsnøvn',
			'contact_name'  => 'Kontaktpersónur',
			'phone'         => 'Telefonnummar',
			'billing_email' => 'Emailadressa til fakturering',
		);
	}

	/** @return array<int, string> */
	public static function required(): array {
		return array( 'club_name', 'boat_name', 'contact_name', 'phone', 'billing_email' );
	}

	/**
	 * @param array<string, mixed> $input Already-unslashed data.
	 * @return array<string, string|int>
	 */
	public static function sanitize( array $input ): array {
		return array(
			'club_name'     => self::text( $input['club_name'] ?? '' ),
			'boat_name'     => self::text( $input['boat_name'] ?? '' ),
			'count_women'   => self::nonneg_int( $input['count_women'] ?? 0 ),
			'count_men'     => self::nonneg_int( $input['count_men'] ?? 0 ),
			'sizes_women'   => self::textarea( $input['sizes_women'] ?? '' ),
			'sizes_men'     => self::textarea( $input['sizes_men'] ?? '' ),
			'contact_name'  => self::text( $input['contact_name'] ?? '' ),
			'phone'         => self::text( $input['phone'] ?? '' ),
			'billing_email' => self::email( $input['billing_email'] ?? '' ),
		);
	}

	/**
	 * Return array of field keys that failed validation.
	 *
	 * @param array<string, string|int> $data
	 * @return array<int, string>
	 */
	public static function validate( array $data ): array {
		$errors = array();
		foreach ( self::required() as $key ) {
			if ( '' === trim( (string) ( $data[ $key ] ?? '' ) ) ) {
				$errors[] = $key;
			}
		}
		if ( ! in_array( 'billing_email', $errors, true ) ) {
			if ( false === filter_var( (string) ( $data['billing_email'] ?? '' ), FILTER_VALIDATE_EMAIL ) ) {
				$errors[] = 'billing_email';
			}
		}
		return array_values( array_unique( $errors ) );
	}

	/** @param mixed $value */
	public static function text( $value ): string {
		$s = is_scalar( $value ) ? (string) $value : '';
		$s = strip_tags( $s );
		$s = (string) preg_replace( '/[\r\n\t\0\x0B]+/u', ' ', $s );
		$s = (string) preg_replace( '/\s+/u', ' ', $s );
		return trim( $s );
	}

	/** @param mixed $value */
	public static function textarea( $value ): string {
		$s = is_scalar( $value ) ? (string) $value : '';
		$s = strip_tags( $s );
		$s = str_replace( array( "\r\n", "\r" ), "\n", $s );
		$s = (string) preg_replace( "/[\0\x0B]/", '', $s );
		return trim( $s );
	}

	/** @param mixed $value */
	public static function nonneg_int( $value ): int {
		return max( 0, (int) ( is_scalar( $value ) ? $value : 0 ) );
	}

	/** @param mixed $value */
	public static function email( $value ): string {
		$s = self::text( $value );
		$v = filter_var( $s, FILTER_VALIDATE_EMAIL );
		return is_string( $v ) ? strtolower( $v ) : '';
	}
}
