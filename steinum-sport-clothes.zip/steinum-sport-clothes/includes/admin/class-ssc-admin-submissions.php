<?php
/**
 * Admin submissions page (list + detail view).
 *
 * @package Steinum_Sport_Clothes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Steinum Sport → Fráboðanir admin screen.
 */
class SSC_Admin_Submissions {

	public const PAGE          = 'ssc-submissions';
	public const NONCE_ACTION  = 'ssc_admin_action';
	public const NONCE_NAME    = 'ssc_nonce';

	public function register(): void {
		add_action( 'admin_post_ssc_submission_action', array( $this, 'handle_action' ) );
		add_action( 'admin_post_ssc_purge', array( $this, 'handle_purge' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
	}

	public function enqueue_admin_styles( string $hook ): void {
		if ( false === strpos( $hook, self::PAGE ) ) {
			return;
		}
		wp_register_style( 'ssc-admin', SSC_URL . 'assets/css/admin.css', array(), SSC_VERSION );
		wp_enqueue_style( 'ssc-admin' );
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Ikki loyvi.', 'steinum-sport-clothes' ) );
		}

		$view = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0;
		if ( $view > 0 ) {
			$this->render_detail( $view );
			return;
		}
		$this->render_list();
	}

	private function render_list(): void {
		$table = new SSC_Admin_List_Table();
		$table->prepare_items();
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Fráboðanir', 'steinum-sport-clothes' ); ?></h1>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . SSC_Settings::PAGE ) ); ?>" class="page-title-action"><?php esc_html_e( 'Stillingar', 'steinum-sport-clothes' ); ?></a>
			<hr class="wp-header-end" />

			<?php $this->maybe_render_admin_notice(); ?>

			<form method="get">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE ); ?>" />
				<?php $table->views(); ?>
				<p class="search-box">
					<label class="screen-reader-text" for="ssc-search">Leita</label>
					<input type="search" id="ssc-search" name="s" value="<?php echo esc_attr( (string) ( $_GET['s'] ?? '' ) ); ?>" />
					<input type="date" name="from" value="<?php echo esc_attr( (string) ( $_GET['from'] ?? '' ) ); ?>" />
					<input type="date" name="to"   value="<?php echo esc_attr( (string) ( $_GET['to'] ?? '' ) ); ?>" />
					<?php submit_button( __( 'Filtrera', 'steinum-sport-clothes' ), 'secondary', '', false ); ?>
				</p>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="ssc_submission_action" />
				<input type="hidden" name="op" value="bulk_delete" />
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
				<?php $table->display(); ?>
			</form>

			<hr />
			<h2><?php esc_html_e( 'Viðlíkahald', 'steinum-sport-clothes' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Strika fráboðanir? Hetta er ikki gjørt um aftur.');">
				<input type="hidden" name="action" value="ssc_purge" />
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
				<label>
					<?php esc_html_e( 'Strika fráboðanir eldri enn', 'steinum-sport-clothes' ); ?>
					<input type="number" name="days" value="180" min="1" step="1" />
					<?php esc_html_e( 'dagar', 'steinum-sport-clothes' ); ?>
				</label>
				<?php submit_button( __( 'Strika nú', 'steinum-sport-clothes' ), 'delete', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	private function render_detail( int $id ): void {
		$row = SSC_Store::find( $id );
		if ( ! $row ) {
			echo '<div class="wrap"><h1>Ikki funnin</h1><p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">Aftur</a></p></div>';
			return;
		}
		$labels = SSC_Sanitizer::labels();
		?>
		<div class="wrap">
			<h1>
				<?php echo esc_html( '#' . (int) $row['id'] . ' — ' . $row['club_name'] ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ); ?>" class="page-title-action"><?php esc_html_e( '← Aftur', 'steinum-sport-clothes' ); ?></a>
			</h1>

			<?php $this->maybe_render_admin_notice(); ?>

			<div class="ssc-detail-grid" style="display:grid;grid-template-columns:2fr 1fr;gap:24px;align-items:start;">
				<div>
					<table class="widefat striped">
						<tbody>
							<tr><th>Dato</th><td><?php echo esc_html( (string) $row['created_at'] ); ?></td></tr>
							<tr><th>Støða</th><td><?php echo esc_html( SSC_Store::statuses()[ (string) $row['status'] ] ?? (string) $row['status'] ); ?></td></tr>
							<?php foreach ( $labels as $key => $label ) : ?>
								<tr>
									<th><?php echo esc_html( $label ); ?></th>
									<td><?php echo nl2br( esc_html( (string) $row[ $key ] ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>

					<h2><?php esc_html_e( 'Sendur teldupostur (admin)', 'steinum-sport-clothes' ); ?></h2>
					<pre style="background:#f6f6f6;border:1px solid #ddd;padding:12px;white-space:pre-wrap;"><?php echo esc_html( (string) $row['email_body'] ); ?></pre>
				</div>

				<div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="ssc_submission_action" />
						<input type="hidden" name="op" value="update" />
						<input type="hidden" name="id" value="<?php echo (int) $row['id']; ?>" />
						<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

						<h2><?php esc_html_e( 'Skift støðu', 'steinum-sport-clothes' ); ?></h2>
						<select name="status">
							<?php foreach ( SSC_Store::statuses() as $k => $v ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $row['status'], $k ); ?>><?php echo esc_html( $v ); ?></option>
							<?php endforeach; ?>
						</select>

						<h2><?php esc_html_e( 'Intern viðmerking', 'steinum-sport-clothes' ); ?></h2>
						<textarea name="note" rows="6" class="large-text"><?php echo esc_textarea( (string) $row['note'] ); ?></textarea>

						<p><?php submit_button( __( 'Goym', 'steinum-sport-clothes' ), 'primary', 'save', false ); ?></p>
					</form>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Strika hesa fráboðanina?');">
						<input type="hidden" name="action" value="ssc_submission_action" />
						<input type="hidden" name="op" value="delete" />
						<input type="hidden" name="id" value="<?php echo (int) $row['id']; ?>" />
						<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
						<?php submit_button( __( 'Strika', 'steinum-sport-clothes' ), 'delete', 'submit', false ); ?>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	public function handle_action(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Ikki loyvi.' );
		}
		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );

		$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( (string) $_POST['op'] ) ) : '';
		$id  = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$msg = '';

		switch ( $op ) {
			case 'update':
				$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( (string) $_POST['status'] ) ) : '';
				$note   = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['note'] ) ) : '';
				SSC_Store::set_status( $id, $status, $note );
				$msg = 'updated';
				break;
			case 'delete':
				SSC_Store::delete( $id );
				$msg = 'deleted';
				$id  = 0;
				break;
			case 'bulk_delete':
				$ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) $_POST['ids'] ) : array();
				SSC_Store::delete_many( $ids );
				$msg = 'bulk_deleted';
				break;
		}

		$args = array( 'page' => self::PAGE );
		if ( $id > 0 && 'updated' === $msg ) {
			$args['view'] = $id;
		}
		if ( '' !== $msg ) {
			$args['ssc_msg'] = $msg;
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	public function handle_purge(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Ikki loyvi.' );
		}
		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );
		$days    = isset( $_POST['days'] ) ? max( 1, (int) $_POST['days'] ) : 180;
		$deleted = SSC_Store::purge_older_than( $days );
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE,
					'ssc_msg' => 'purged',
					'n'       => $deleted,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	private function maybe_render_admin_notice(): void {
		if ( empty( $_GET['ssc_msg'] ) ) {
			return;
		}
		$msg = (string) $_GET['ssc_msg'];
		$map = array(
			'updated'      => array( 'success', 'Fráboðan dagført.' ),
			'deleted'      => array( 'success', 'Fráboðan strikað.' ),
			'bulk_deleted' => array( 'success', 'Fráboðanir strikaðar.' ),
			'purged'       => array( 'success', sprintf( 'Strikaðar: %d.', (int) ( $_GET['n'] ?? 0 ) ) ),
		);
		if ( ! isset( $map[ $msg ] ) ) {
			return;
		}
		printf(
			'<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
			esc_attr( $map[ $msg ][0] ),
			esc_html( $map[ $msg ][1] )
		);
	}
}
