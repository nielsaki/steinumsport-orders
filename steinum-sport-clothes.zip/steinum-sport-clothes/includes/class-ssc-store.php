<?php
/**
 * Custom DB table for storing form submissions.
 *
 * @package Steinum_Sport_Clothes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Submissions store.
 */
class SSC_Store {

	public const SCHEMA_VERSION = '1';
	public const OPTION_SCHEMA  = 'ssc_db_schema_version';
	public const TABLE          = 'ssc_submissions';

	public const STATUS_RECEIVED   = 'received';
	public const STATUS_PROCESSING = 'processing';
	public const STATUS_DELIVERED  = 'delivered';
	public const STATUS_CANCELLED  = 'cancelled';

	/** @return array<string, string> */
	public static function statuses(): array {
		return array(
			self::STATUS_RECEIVED   => 'Móttikin',
			self::STATUS_PROCESSING => 'Í arbeiði',
			self::STATUS_DELIVERED  => 'Avgreitt',
			self::STATUS_CANCELLED  => 'Avlýst',
		);
	}

	public static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Create or upgrade the submissions table.
	 *
	 * Called from the plugin activation hook and on schema-version mismatch.
	 */
	public static function maybe_install(): void {
		$current = (string) get_option( self::OPTION_SCHEMA, '' );
		if ( $current === self::SCHEMA_VERSION ) {
			return;
		}

		global $wpdb;
		$table   = self::table_name();
		$charset = method_exists( $wpdb, 'get_charset_collate' ) ? $wpdb->get_charset_collate() : '';

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'received',
			club_name VARCHAR(255) NOT NULL,
			boat_name VARCHAR(255) NOT NULL,
			count_women INT UNSIGNED NOT NULL DEFAULT 0,
			count_men INT UNSIGNED NOT NULL DEFAULT 0,
			sizes_women TEXT NOT NULL,
			sizes_men TEXT NOT NULL,
			contact_name VARCHAR(255) NOT NULL,
			phone VARCHAR(64) NOT NULL,
			billing_email VARCHAR(255) NOT NULL,
			email_body LONGTEXT NOT NULL,
			note TEXT NOT NULL,
			PRIMARY KEY  (id),
			KEY idx_status (status),
			KEY idx_created (created_at),
			KEY idx_email (billing_email)
		) {$charset};";

		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}
		dbDelta( $sql );

		update_option( self::OPTION_SCHEMA, self::SCHEMA_VERSION, false );
	}

	/**
	 * Persist a submission. Returns the new row ID, or 0 on failure / when storage is disabled.
	 *
	 * @param array<string, string|int> $data       Sanitized submission data.
	 * @param string                    $email_body Plain-text admin email body (for audit).
	 */
	public static function insert( array $data, string $email_body = '' ): int {
		if ( false === apply_filters( 'ssc_store_submission', true, $data ) ) {
			return 0;
		}
		global $wpdb;
		$now = gmdate( 'Y-m-d H:i:s' );
		$row = array(
			'created_at'    => $now,
			'updated_at'    => $now,
			'status'        => self::STATUS_RECEIVED,
			'club_name'     => (string) ( $data['club_name'] ?? '' ),
			'boat_name'     => (string) ( $data['boat_name'] ?? '' ),
			'count_women'   => (int) ( $data['count_women'] ?? 0 ),
			'count_men'     => (int) ( $data['count_men'] ?? 0 ),
			'sizes_women'   => (string) ( $data['sizes_women'] ?? '' ),
			'sizes_men'     => (string) ( $data['sizes_men'] ?? '' ),
			'contact_name'  => (string) ( $data['contact_name'] ?? '' ),
			'phone'         => (string) ( $data['phone'] ?? '' ),
			'billing_email' => (string) ( $data['billing_email'] ?? '' ),
			'email_body'    => (string) $email_body,
			'note'          => '',
		);
		$ok = $wpdb->insert( self::table_name(), $row );
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Fetch submissions matching simple filters.
	 *
	 * @param array{status?: string, search?: string, from?: string, to?: string} $filters
	 * @param array{per_page?: int, page?: int}                                    $pagination
	 * @return array{rows: array<int, array<string, mixed>>, total: int}
	 */
	public static function all( array $filters = array(), array $pagination = array() ): array {
		global $wpdb;
		$table = self::table_name();

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $filters['status'] ) && array_key_exists( $filters['status'], self::statuses() ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $filters['status'];
		}
		if ( ! empty( $filters['search'] ) ) {
			$like     = '%' . self::esc_like( (string) $filters['search'] ) . '%';
			$where[]  = '(club_name LIKE %s OR boat_name LIKE %s OR contact_name LIKE %s OR billing_email LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		if ( ! empty( $filters['from'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = (string) $filters['from'] . ' 00:00:00';
		}
		if ( ! empty( $filters['to'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = (string) $filters['to'] . ' 23:59:59';
		}

		$per_page = isset( $pagination['per_page'] ) ? max( 1, (int) $pagination['per_page'] ) : 25;
		$page     = isset( $pagination['page'] ) ? max( 1, (int) $pagination['page'] ) : 1;
		$offset   = ( $page - 1 ) * $per_page;

		$where_sql = implode( ' AND ', $where );
		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$rows_sql  = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";

		$total = $params
			? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) )
			: (int) $wpdb->get_var( $count_sql );

		$rows_params = array_merge( $params, array( $per_page, $offset ) );
		$rows        = (array) $wpdb->get_results( $wpdb->prepare( $rows_sql, $rows_params ), ARRAY_A );

		return array(
			'rows'  => $rows,
			'total' => $total,
		);
	}

	/** @return array<string, mixed>|null */
	public static function find( int $id ): ?array {
		global $wpdb;
		$table = self::table_name();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	public static function set_status( int $id, string $status, ?string $note = null ): bool {
		if ( ! array_key_exists( $status, self::statuses() ) ) {
			return false;
		}
		global $wpdb;
		$update = array(
			'status'     => $status,
			'updated_at' => gmdate( 'Y-m-d H:i:s' ),
		);
		if ( null !== $note ) {
			$update['note'] = $note;
		}
		$ok = $wpdb->update( self::table_name(), $update, array( 'id' => $id ) );
		return false !== $ok;
	}

	public static function delete( int $id ): bool {
		global $wpdb;
		return (bool) $wpdb->delete( self::table_name(), array( 'id' => $id ) );
	}

	/** @param array<int, int> $ids */
	public static function delete_many( array $ids ): int {
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids ) {
			return 0;
		}
		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$sql          = $wpdb->prepare( 'DELETE FROM ' . self::table_name() . " WHERE id IN ({$placeholders})", $ids );
		return (int) $wpdb->query( $sql );
	}

	public static function purge_older_than( int $days ): int {
		$days = max( 0, $days );
		if ( 0 === $days ) {
			return 0;
		}
		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS_FALLBACK() ) );
		return (int) $wpdb->query(
			$wpdb->prepare( 'DELETE FROM ' . self::table_name() . ' WHERE created_at < %s', $cutoff )
		);
	}

	private static function esc_like( string $text ): string {
		global $wpdb;
		if ( method_exists( $wpdb, 'esc_like' ) ) {
			return $wpdb->esc_like( $text );
		}
		return addcslashes( $text, '_%\\' );
	}
}

if ( ! function_exists( 'DAY_IN_SECONDS_FALLBACK' ) ) {
	/**
	 * Returns DAY_IN_SECONDS, falling back to 86400 outside of WordPress.
	 */
	function DAY_IN_SECONDS_FALLBACK(): int { // phpcs:ignore
		return defined( 'DAY_IN_SECONDS' ) ? (int) DAY_IN_SECONDS : 86400;
	}
}
