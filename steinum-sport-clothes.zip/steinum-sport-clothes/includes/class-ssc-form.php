<?php
/**
 * Frontend form: shortcode renderer + POST handler.
 *
 * @package Steinum_Sport_Clothes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the shortcode and handles POST submissions.
 */
class SSC_Form {

	public const ACTION    = 'ssc_submit';
	public const NONCE     = 'ssc_form';
	public const SHORTCODE = 'steinum_sport_clothes_form';
	public const SHORTCODE_ALIAS = 'ssc_form';

	public function register(): void {
		add_shortcode( self::SHORTCODE, array( $this, 'render' ) );
		add_shortcode( self::SHORTCODE_ALIAS, array( $this, 'render' ) );
		add_action( 'init', array( $this, 'maybe_handle_submit' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function enqueue_assets(): void {
		wp_register_style(
			'ssc-frontend',
			SSC_URL . 'assets/css/frontend.css',
			array(),
			SSC_VERSION
		);
	}

	/**
	 * Sample submission used by the admin "Send test" button.
	 *
	 * @return array<string, string|int>
	 */
	public static function sample_data( string $billing_email = '' ): array {
		if ( '' === $billing_email || ! filter_var( $billing_email, FILTER_VALIDATE_EMAIL ) ) {
			$billing_email = (string) get_option( 'admin_email', 'test@example.com' );
		}
		return array(
			'club_name'     => 'Kappróðrarfelag Havnar',
			'boat_name'     => 'Selin (royndarbátur)',
			'count_women'   => 4,
			'count_men'     => 3,
			'sizes_women'   => "Maria — M\nEva — L\nKaria — S\nRóa — M",
			'sizes_men'     => "Jón — XL\nPáll — L\nHans — M",
			'contact_name'  => 'Hans Hansen (royndarprógv)',
			'phone'         => '+298 12 34 56',
			'billing_email' => $billing_email,
		);
	}

	/**
	 * Returns the URL-segment to pass when redirecting after submit.
	 */
	private function redirect_target( bool $ok ): string {
		$ref = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( (string) $_SERVER['HTTP_REFERER'] ) ) : '';
		if ( '' === $ref ) {
			$ref = home_url( '/' );
		}
		return add_query_arg(
			array(
				'ssc_status' => $ok ? 'ok' : 'fail',
			),
			$ref
		);
	}

	public function maybe_handle_submit(): void {
		if ( empty( $_POST['action'] ) || self::ACTION !== $_POST['action'] ) {
			return;
		}
		check_admin_referer( self::NONCE );

		$raw  = wp_unslash( $_POST );
		$data = SSC_Sanitizer::sanitize( $raw );
		$errors = SSC_Sanitizer::validate( $data );

		if ( ! empty( $_POST['ssc_hp'] ) ) {
			$errors[] = '__honeypot';
		}

		if ( $errors ) {
			set_transient( 'ssc_errors_' . self::client_key(), $errors, 60 );
			set_transient( 'ssc_input_' . self::client_key(), $data, 60 );
			wp_safe_redirect( $this->redirect_target( false ) );
			exit;
		}

		$ok = ( new SSC_Submission() )->handle( $data );

		delete_transient( 'ssc_errors_' . self::client_key() );
		delete_transient( 'ssc_input_' . self::client_key() );
		wp_safe_redirect( $this->redirect_target( $ok ) );
		exit;
	}

	public function render(): string {
		wp_enqueue_style( 'ssc-frontend' );

		$labels = SSC_Sanitizer::labels();
		$key    = self::client_key();
		$errors = (array) get_transient( 'ssc_errors_' . $key );
		$input  = (array) get_transient( 'ssc_input_' . $key );

		ob_start();
		$status = isset( $_GET['ssc_status'] ) ? (string) $_GET['ssc_status'] : '';
		if ( 'ok' === $status ) {
			echo '<div class="ssc-notice ssc-notice--ok" role="status">'
				. esc_html__( 'Takk fyri! Innskráseting móttikin.', 'steinum-sport-clothes' )
				. '</div>';
		} elseif ( 'fail' === $status ) {
			echo '<div class="ssc-notice ssc-notice--err" role="alert">'
				. esc_html__( 'Onkur villa hendi. Vinarliga royn aftur.', 'steinum-sport-clothes' )
				. '</div>';
		}
		?>
		<form class="ssc-form" method="post" novalidate>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
			<?php wp_nonce_field( self::NONCE ); ?>
			<p style="position:absolute;left:-9999px;" aria-hidden="true">
				<label>Lat tóman<input type="text" name="ssc_hp" tabindex="-1" autocomplete="off" /></label>
			</p>

			<?php foreach ( $labels as $key => $label ) :
				$is_textarea = in_array( $key, array( 'sizes_women', 'sizes_men' ), true );
				$type        = 'billing_email' === $key ? 'email' : ( in_array( $key, array( 'count_women', 'count_men' ), true ) ? 'number' : 'text' );
				$value       = isset( $input[ $key ] ) ? (string) $input[ $key ] : '';
				$has_err     = in_array( $key, $errors, true );
				$id          = 'ssc-' . str_replace( '_', '-', $key );
				?>
				<p class="ssc-field<?php echo $has_err ? ' ssc-field--error' : ''; ?>">
					<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
					<?php if ( $is_textarea ) : ?>
						<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="4"><?php echo esc_textarea( $value ); ?></textarea>
					<?php else : ?>
						<input
							type="<?php echo esc_attr( $type ); ?>"
							id="<?php echo esc_attr( $id ); ?>"
							name="<?php echo esc_attr( $key ); ?>"
							value="<?php echo esc_attr( $value ); ?>"
							<?php echo 'number' === $type ? 'min="0" step="1"' : ''; ?>
						/>
					<?php endif; ?>
				</p>
			<?php endforeach; ?>

			<p class="ssc-actions">
				<button type="submit" class="ssc-submit"><?php esc_html_e( 'Send', 'steinum-sport-clothes' ); ?></button>
			</p>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	private static function client_key(): string {
		$ip  = $_SERVER['REMOTE_ADDR'] ?? '';
		$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
		return md5( $ip . '|' . $ua );
	}
}
