<?php
/**
 * Minimal pure-PHP PDF generator for the order receipt.
 *
 * Uses built-in Type1 Helvetica + WinAnsi (CP1252) encoding, which covers
 * all Faroese characters (á é í ó ú ý ð ø æ + uppercase).
 *
 * @package Steinum_Sport_Clothes
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'SSC_TESTING' ) ) {
	exit;
}

/**
 * PDF receipt renderer.
 */
class SSC_PDF {

	private int $page_w = 595;
	private int $page_h = 842;
	private int $margin_top = 60;
	private int $margin_left = 50;
	private int $margin_right = 50;
	private int $margin_bottom = 60;

	/** @var array<int, string> Object bodies; IDs are 1-indexed. */
	private array $objects = array();
	/** @var array<int, int> */
	private array $page_ids = array();
	private string $stream = '';
	private int $y = 0;
	private int $font_regular_id = 0;
	private int $font_bold_id = 0;

	/**
	 * Render receipt PDF bytes.
	 *
	 * @param array<string, string|int> $data
	 * @param array<string, string>     $labels
	 * @param array<string, string>     $meta   Extra header rows.
	 */
	public function render( array $data, array $labels, string $title, array $meta = array() ): string {
		$this->objects  = array();
		$this->page_ids = array();
		$this->stream   = '';

		$this->add_object( '' );
		$this->add_object( '' );

		$this->font_regular_id = $this->add_object(
			'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'
		);
		$this->font_bold_id = $this->add_object(
			'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'
		);

		$this->start_page();
		$this->heading( $title, 18 );

		foreach ( $meta as $k => $v ) {
			$this->line( $k . ': ' . $v, 10, false );
		}
		if ( $meta ) {
			$this->spacer( 8 );
		}

		foreach ( $labels as $key => $label ) {
			$this->line( $label, 11, true );
			$val = (string) ( $data[ $key ] ?? '' );
			if ( '' === trim( $val ) ) {
				$val = '-';
			}
			foreach ( preg_split( '/\R/u', $val ) ?: array( $val ) as $sub ) {
				$this->wrapped( '' === $sub ? ' ' : $sub, 11, false );
			}
			$this->spacer( 4 );
		}

		return $this->finish();
	}

	private function add_object( string $body ): int {
		$this->objects[] = $body;
		return count( $this->objects );
	}

	private function start_page(): void {
		if ( '' !== $this->stream ) {
			$this->flush_page();
		}
		$this->stream = '';
		$this->y     = $this->page_h - $this->margin_top;
	}

	private function flush_page(): void {
		$content    = $this->stream;
		$content_id = $this->add_object(
			'<< /Length ' . strlen( $content ) . " >>\nstream\n" . $content . "\nendstream"
		);
		$page_id = $this->add_object(
			'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . $this->page_w . ' ' . $this->page_h . ']'
			. ' /Resources << /Font << /F1 ' . $this->font_regular_id . ' 0 R'
			. ' /F2 ' . $this->font_bold_id . ' 0 R >> >>'
			. ' /Contents ' . $content_id . ' 0 R >>'
		);
		$this->page_ids[] = $page_id;
		$this->stream     = '';
	}

	private function heading( string $text, int $size ): void {
		$this->ensure_space( $size + 8 );
		$this->line( $text, $size, true );
		$this->spacer( 6 );
		$this->hr();
		$this->spacer( 8 );
	}

	private function hr(): void {
		$x1           = $this->margin_left;
		$x2           = $this->page_w - $this->margin_right;
		$y            = $this->y;
		$this->stream .= "q\n0.7 w\n0.6 0.6 0.6 RG\n{$x1} {$y} m {$x2} {$y} l S\nQ\n";
	}

	private function line( string $text, int $size, bool $bold ): void {
		$this->ensure_space( $size + 4 );
		$font         = $bold ? 'F2' : 'F1';
		$x            = $this->margin_left;
		$y            = $this->y;
		$esc          = self::encode( $text );
		$this->stream .= "BT\n/{$font} {$size} Tf\n{$x} {$y} Td\n({$esc}) Tj\nET\n";
		$this->y     -= ( $size + 3 );
	}

	private function wrapped( string $text, int $size, bool $bold ): void {
		$max = (int) floor( ( $this->page_w - $this->margin_left - $this->margin_right ) / ( $size * 0.52 ) );
		if ( $max < 10 ) {
			$max = 10;
		}
		$words = explode( ' ', $text );
		$cur   = '';
		foreach ( $words as $w ) {
			$try = ( '' === $cur ) ? $w : ( $cur . ' ' . $w );
			if ( self::mb_len( $try ) > $max && '' !== $cur ) {
				$this->line( $cur, $size, $bold );
				$cur = $w;
			} else {
				$cur = $try;
			}
		}
		if ( '' !== $cur ) {
			$this->line( $cur, $size, $bold );
		}
	}

	private function spacer( int $h ): void {
		$this->y -= $h;
	}

	private function ensure_space( int $h ): void {
		if ( $this->y - $h < $this->margin_bottom ) {
			$this->start_page();
		}
	}

	private function finish(): string {
		$this->flush_page();

		$this->objects[0] = '<< /Type /Catalog /Pages 2 0 R >>';
		$kids             = implode(
			' ',
			array_map( static fn( $id ): string => $id . ' 0 R', $this->page_ids )
		);
		$count            = count( $this->page_ids );
		$this->objects[1] = "<< /Type /Pages /Kids [{$kids}] /Count {$count} >>";

		$out     = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
		$offsets = array();
		foreach ( $this->objects as $i => $body ) {
			$offsets[ $i + 1 ] = strlen( $out );
			$out              .= ( $i + 1 ) . " 0 obj\n" . $body . "\nendobj\n";
		}
		$xref_pos = strlen( $out );
		$size     = count( $this->objects ) + 1;
		$out     .= "xref\n0 {$size}\n";
		$out     .= sprintf( "%010d %05d f \n", 0, 65535 );
		for ( $i = 1; $i < $size; $i++ ) {
			$out .= sprintf( "%010d %05d n \n", $offsets[ $i ], 0 );
		}
		$out .= "trailer\n<< /Size {$size} /Root 1 0 R >>\nstartxref\n{$xref_pos}\n%%EOF\n";
		return $out;
	}

	/**
	 * UTF-8 → WinAnsi (CP1252) with PDF string escaping.
	 */
	public static function encode( string $text ): string {
		$converted = false;
		if ( function_exists( 'iconv' ) ) {
			$converted = @iconv( 'UTF-8', 'CP1252//TRANSLIT//IGNORE', $text );
		}
		if ( false === $converted ) {
			$converted = function_exists( 'mb_convert_encoding' )
				? (string) mb_convert_encoding( $text, 'CP1252', 'UTF-8' )
				: $text;
		}
		return strtr( (string) $converted, array( '\\' => '\\\\', '(' => '\\(', ')' => '\\)' ) );
	}

	private static function mb_len( string $s ): int {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $s, 'UTF-8' ) : strlen( $s );
	}
}
